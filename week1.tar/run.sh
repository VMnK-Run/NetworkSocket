#! /bin/bash
# ./echo_client 127.0.0.1 9999 ./samples/sample_request_example 
# ./echo_client 127.0.0.1 9999 ./samples/request_head 
# ./echo_client 127.0.0.1 9999 ./samples/test
# ./echo_client 127.0.0.1 9999 ./samples/request_get
# ./echo_client 127.0.0.1 9999 ./samples/request_post
# ./echo_client 127.0.0.1 9999 ./samples/sample_request_realistic
./echo_client 127.0.0.1 9999 ./samples/myTest
